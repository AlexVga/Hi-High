#include <iostream>
#include "functions.h"
using namespace std;

int main(int argc, char *argv[]) {
	cout << "Press Enter!";
	string user = "";
	int count = 0;
	getline (cin, user);
	while (user == ""){
		if (count == 4) {
			openLink("weed.jpg",argc,argv);
			cout << "Close Picture and click on program!";
		}
		else if (count == 9){
			openLink("dontweed.jpg",argc,argv);
			cout << "Close Picture and click on program!"<< endl;
		}
		else if (count == 3){
			cout << "High!"<< endl;
		}
		else if (count == 8){
			cout << "Don't get high!!";
		}
		else if (count == 10){
			openLink("http://drugabuse.com/whos-smoking-weed-these-days-you-asked-the-cdc-answered/", argc, argv);
			count = 0;
		}
		else {
			cout << "Hi!" << " ";
			
		}
				count ++;
		getline (cin, user);
	}
}