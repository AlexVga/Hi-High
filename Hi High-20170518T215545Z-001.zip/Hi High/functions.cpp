#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <cctype>
#include <locale>
#include "functions.h"
using namespace std;

//Contributor: Kimber
#define RESET   "\033[0m"
#define BLACK   "\033[30m"      /* Black */
#define RED     "\033[31m"      /* Red */
#define GREEN   "\033[32m"      /* Green */
#define YELLOW  "\033[33m"      /* Yellow */
#define BLUE    "\033[34m"      /* Blue */
#define MAGENTA "\033[35m"      /* Magenta */
#define CYAN    "\033[36m"      /* Cyan */
#define WHITE   "\033[37m"      /* White */
#define BOLDBLACK   "\033[1m\033[30m"      /* Bold Black */
#define BOLDRED     "\033[1m\033[31m"      /* Bold Red */
#define BOLDGREEN   "\033[1m\033[32m"      /* Bold Green */
#define BOLDYELLOW  "\033[1m\033[33m"      /* Bold Yellow */
#define BOLDBLUE    "\033[1m\033[34m"      /* Bold Blue */
#define BOLDMAGENTA "\033[1m\033[35m"      /* Bold Magenta */
#define BOLDCYAN    "\033[1m\033[36m"      /* Bold Cyan */
#define BOLDWHITE   "\033[1m\033[37m"      /* Bold White */
#define CLEAR "\033[2J"  // clear screen escape code 



//Contributor: Kimber
//asks user the 'question' and returns the answer
string ask(string question){
	string answer; 
	cout << question;
	getline(cin, answer);
	return answer;

}

//prints the given string
void print(string sentence)
{
		cout << sentence<< endl;
}
//prints the given string 'times' amount
void printMany(string sentence, string times="1")
{
	int timess =atoi(times.c_str());
	for(int i;i< timess;i++){
		cout << sentence; 
	}
	cout << endl;
}

//prints the given vector
void printInt(int number)
{
	cout << number << endl;
}

//prints the given vector
void printVector(vector<string> vect)
{
	if(!vect.empty()){
		copy(vect.begin(), vect.end(), ostream_iterator<string>(cout, ", "));
	}
	else
	{
		cout << "Empty vector";
	}
}

//returns all of the words in the words.txt file
vector<string> getWords(vector<string> words,string filename)//Contributor: Kimber
{
	fstream File;
	
	try
	{ 
		File.open(filename);
		}
	catch (int e)
	{
		print("There was an error in opening the file.");		
	}
	
	string line;
	string word;
	words.clear();

	if(File.is_open())
	{
		while(getline(File, line))
		{
			for(int i=0;i < line.length(); i++)//loops through the line
			{		
				if(char(line[i]) == '.')
				{
					words.push_back(word);
					word = "";
					i++;
				}
				else if(char(line[i])=='\n')
				{
					words.erase(words.end());
				}
				word+= line[i];
			}//endfor
			
		}//endwhile
		File.close();
		return words;
	}//endif
	else
	{
		print(filename +" is not open");
	}
	return words;
}


string getColor(char color)//Contributor: Kimber
{
	
	switch(color)
	{
		case 'r':
			return RED;
		case 'R':
			return BOLDRED;
		case 'b':
			return BLACK;
		case 'B':
			return BOLDBLACK;
		case 'g':
			return GREEN;
		case 'G':
			return BOLDGREEN;
		case 'y':
			return YELLOW;
		case 'Y':
			return BOLDYELLOW;
		case 'u':
			return BLUE;
		case 'U':
			return BOLDBLUE;
		case 'm':
			return MAGENTA;
		case 'M':
			return BOLDMAGENTA;
		case 'c':
			return CYAN;
		case 'C':
			return BOLDCYAN;
		case 'w':
			return WHITE;
		case 'W':
			return BOLDWHITE;
		case '1':
			return RESET;
		case '2':
			return CLEAR;
		default :
			return WHITE;
		
	}
	
}

//Contributor: Kimber
void openLink(string url,int argc, char *argv[]){//Use example: openLink("http://www.google.com", argc, argv);
	
	for (int i = 1; i < argc; i++) {
		url = url + string(argv[i]);
		if (i != argc-1) url = url + string("+");
	}

	cout << url << endl;
	string op = string("open ").append(url);
	system(op.c_str());
	
}
//Contributor: Johnathon
bool fexists(string filename)
{
    ifstream f;
    f.open(filename);
    return f.is_open();
}
//Contributor: Johnathon
string fileSelecting() {
    int inFileNum = 1;
    string inFileNumString = "";
    string outPath = "";
    string inPath = "helpfileNumberCounter.txt";
    bool inExists = false;
    ofstream outFile;
    ofstream inFile;
    
    inExists = fexists(inPath);
    
    if(inExists == false)
    {
        outFile.open(inPath, ios::out);
        outFile << "1";
        outFile.close();
    }
    else
    {
        inFile.open(inPath, ios::in);
        getline(cin, inFileNumString);
        ++inFileNum;
        cout << inFileNum << endl;
        inFile.close();
        outFile.open(inPath, ios::out);
        outFile << inFileNum;
        outFile.close();
    }
    outPath = "helpfile"+to_string(inFileNum)+".txt";
    return outPath;
}
//Contributor: Johnathon
void fileRecording(string responses, string pth) {
    ofstream outFile;
    
    outFile.open(pth, ios::app);
    
    if(outFile.is_open())
    {
        if(responses != "exit")
            outFile << responses << endl;
    }
    else
        cout << "File could not be accessed." << endl;
    outFile.close();
}
//Contributor: Johnathon
void fileFunction() {
    string conversation = "";
    string path = "";

    path = fileSelecting();
    
    while(conversation != "exit")
    {
        cout << "enter thing" << endl;
        getline(cin, conversation);
        conversation + "\n";
        fileRecording(conversation, path);
    }
}
//Contributor: Kimber
int analyzeIn(string question, vector<string> words, vector<string> scores){
	string answer;
	string word;
    string line;
	vector<string> answer_words;
	cout << question << endl;
	cin >> answer;

	for (int k = 0;k < answer.length(); k++)//loops through the line
	{
		if (char(answer[k]) == '.')
		{
			answer_words.push_back(word);
			word = "";
			k++;
		}
		word += line[k];
	}//endfor

	
	for (int j = 0;j < sizeof(answer_words); j++) {
		for (int i; i < sizeof(words); i++) {
			if (answer_words[j] ==words[i]) {
				return atoi(scores[i].c_str());
			}//e i
		
		
		}// e f
	
	}//e f

    return 0;



}//end of function




