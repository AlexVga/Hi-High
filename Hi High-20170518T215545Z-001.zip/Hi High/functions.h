#include <iostream>
#include <string>
#include <vector>
using namespace std;
//Contributor: Kimber


string ask(string question);

void print(string sentence);

void printMany(string sentence,string times);

void printInt(int number);

void printVector(vector<string> vect);

vector<string> getWords(vector<string> words,string filename);

string getColor(char color);

void openLink(string url, int argc, char *argv[]);

int analyzeIn(string question, vector<string> words, vector<string> scores);
